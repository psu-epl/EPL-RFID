#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <unistd.h>
/*
	Parsing and stuff


*/

int bintoint (char *s); 
void to_bin_str(unsigned int value, char *res, int *p);
char* convert(unsigned int value);
char * hextoBinary(char * memoryAddress);
char * indexCalc (double input, char * line, int *islct, int *oslct);
char * offsetCalc (double input, char * line, int* oslct);



int main(/*int argc char* argv[]*/)
{
	int memoryAddress;  // for hex addresses

	int i,x, j;
	

	char *p;
	int size = 200;
	

	char line [201];
	line[201] = '\0';
	int length = 0;

	//Search string
	char startBits[] = "0000001";
 	int len = strlen(startBits);

	FILE *filename;
	filename = fopen("trace.txt", "r");  // using sample trace file
	
	
	// Test asc to binary
	char* memoryAddr = (char*)malloc(sizeof(char)*1000);

		// 
	

	printf("Importing file from text and searching 0000001\n");

	//while (fscanf(filename, "%d" , &memoryAddress) > 0) // split stream into two variables
	//{
fscanf(filename, "%200c" ,line);

		printf("value of line: %s\n", line);
		length = strlen(line);
		char val[length];// = char malloc(sizeof(char)*len);
		strncpy(val, line, length+1);
		//val[length+1] = '\0';	
		printf("value of val: %s\n\n", val);

	
			
	//}
	fclose(filename);
	char * ret;
	ret = strstr(line, startBits) ;
	if(ret){
	printf("Found: %s\n", ret+27);
	char cardNo [25];
	//cardNo[25] = '\0';
	strncpy(cardNo, ret+19, 24);
	int number = bintoint(cardNo);
	//unsigned int number = atoi(cardNo);
	printf("Card Number: %s, %x\n", cardNo, number);
	char url[128] = "https://www.google.com"; //you could make this bigger if you want
   // scanf("%s",url); // get the url from the console

    char call[256];
    strcpy(call, "xdg-open "); // web browser command
    strcat(call, url); // append url

    system(call);

}

	//printf("value of memoryAddr: %d\n\n", val[1]);

	return 0;
}

// FUNCTIONS are defined here

char * itoa(int  num, char *input)
{
		if(input == 0)
				{
							return 0;
								}
			sprintf(input,"%d",num);
				return input;
}



int bintoint (char *s) 
{
		return (int) strtol(s, NULL, 2);
}


void to_bin_str(unsigned int value, char *res, int *p)
{
		char base_range[] = "01";
		  if (value >= 2) 
					{
						     to_bin_str(value / 2, res, p);
									}
			  res[(*p)++] = base_range[value % 2];
}
char* convert(unsigned int value)
{
	  char* result = (char*)malloc(sizeof(char) * 32);
		  int i = 0;
				int length;
				  to_bin_str(value, result, &i);
					  result[i] = '\0';
							length = strlen(result);
								memmove(result+32-length, result, length+1);
									memset(result,'0', 32-length);

										return (result);
}


char * hextoBinary(char * memoryAddress)
{
		int size =33;
			char *ptr;
				long binary;
					unsigned int  bin;
						
						char *res = (char*)malloc(sizeof(char)*1000);
							// Binary format hex
							binary = strtol(memoryAddress, 0, 16);
								bin =(unsigned int)binary;
									res = convert(bin);

										return (res);

}


char * offsetCalc (double input, char * line, int *oslct)
{
			
		int slctArry;//, islct;
			double selector;
				char * offset;
					selector = log2(input);
					  *oslct = (int)selector;			//oslct is number of bits representing offset

							// offset calculation
							slctArry = 31 - (*oslct);

								char* offPtr = &line[slctArry]+1;

									offset = (char*)malloc(sizeof(char)*(*oslct)); //offset bits
										strncpy(offset, offPtr,(*oslct));
										//	printf("Offset : %s\n", offset);

											return offset;
}


char * indexCalc (double input, char * line, int *islct, int *oslct)
{
		int slctArry;//, islct;
			double selector;
				char * index;
					selector = log2(input);
					  *islct = (int)selector;			//oslct is number of bits representing offset

							// offset calculation
							slctArry = 31 - (*oslct + *islct);

								char* indPtr = &line[slctArry]+1;

									index = (char*)malloc(sizeof(char)*(*islct)); //offset bits
										strncpy(index, indPtr,(*islct));
										//	printf("Offset : %s\n", offset);

											return index;
}

/*


			
			if ((strcmp(tag,set[indexDec].tag1[j])!=0)&& (strcmp(line2,set[indexDec].tag1[j])!=0)){
				printf("Cache miss...copy to cache...DEAL WITH EVICTION\n");
				
				printf("For index %d and way %d:  %s \n", indexDec, j, set[indexDec].tag1[j]);//, set[indexDec].tag1[1], set[indexDec].tag1[2], set[indexDec].tag1[3]);
				if (set[indexDec].valid == 0)
				{
					goto MISS;
				}
				// ELSE is replacement policy
				
			}
			else// if (strcmp(tag,set[indexDec].tag1[j])==0)
			{
			//	if(!(set[indexDec].tag1[j])){
				printf("Cache hit...DO SOMETHING[%d} \n",j);
				hits += 1;
				break;
			//	goto HIT;
				}
			//j+=1;
		}	
			
			
			if (strcmp(tag,set[indexDec].tag1[j])==0)
			{
				printf("Cache hit...DO SOMETHING[%d} \n",j);
				goto HIT;
				

			}
			
			else
			{
				printf("Cache miss...copy to cache...DEAL WITH EVICTION\n");
			//	if(!(set[indexDec].tag1[j])){

				goto MISS;
			//	}

			}
	
		}
		
	//	HIT:
		//		hits += 1;
		MISS:
				printf("j: %d index: %d slct arry Size: %d\n", j, indexDec, slctArry);
				misses=accesses-hits;
			//	printf("j: %d index: %d slct arry Size: %d", j, indexDec, slctArry);
		//	if (strcmp(line2,set[indexDec].tag1[j])!=0){
				if (j<ways){	
				strncpy(set[indexDec].tag1[j],tag, slctArry);
				set[indexDec].valid=	1;
			}*/
	//			printf("For index %d and way %d:  %s \n", indexDec, j, set[indexDec].tag1[j]);//, set[indexDec].tag1[1], set[indexDec].tag1[2], set[indexDec].tag1[3]);
			
		/* INDEX comparison
		if (strcmp(tag,*(table+indexDec))==0)
		{
			hits += 1;
			printf("Cache hit...DO SOMETHING \n");
		}
		else
		{
			misses +=1;
			printf("Cache miss...copy to cache...DEAL WITH EVICTION\n");
			strncpy(*(table+indexDec),tag, slctArry);
			printf ("tag location: %s\n\n",*(table+indexDec)); 
		}
*/		
		
